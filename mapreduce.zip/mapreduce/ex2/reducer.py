#!/usr/bin/env python

from operator import itemgetter
import sys

key = None
value = 0
count = 0

# input comes from STDIN
for line in sys.stdin:
	# remove leading and trailing whitespace
	line = line.strip()
	row = line.split("\t")
	(key,value) = row

	count += 1
	print(count,key,value)
	
